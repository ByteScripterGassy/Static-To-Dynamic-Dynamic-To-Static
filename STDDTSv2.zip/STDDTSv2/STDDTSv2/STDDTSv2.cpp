// STDDTSv2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <thread>
#include <chrono>
#include <sstream>

int main()
{
    uintptr_t staticBase = 0x0;
    uintptr_t dynamicBase = 0x0;
    std::string staticHexString = "";
    std::string dymanicHexString = "";
    std::string sod = "";

    while (true) {
        if (staticBase == 0x0 && dynamicBase == 0x0) { // Segment For Init
            std::cout << "Static Base: ";
            std::cin >> staticHexString;
            staticBase =  std::stoull(staticHexString, 0, 16);
            std::cout << "DEBUG: " << staticBase << std::endl;
            std::cout << "Dynamic Base: ";
            std::cin >> dymanicHexString;
            dynamicBase = std::stoull(dymanicHexString, 0, 16);
            std::cout << "DEBUG: " << dynamicBase << std::endl;
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        system("cls");
        std::cout << "Static [S] Or Dynamic [D]: ";
        std::cin >> sod;
        if (sod == "S" || sod == "s") {
            std::string staticAddressString = "";
            uintptr_t staticAddress = 0x0;
            uintptr_t dynamicAddress = 0x0;
            std::cout << "Static Address: ";
            std::cin >> staticAddressString;
            staticAddress = std::stoull(staticAddressString, 0, 16); // Converts it to a large value since stoi is 32 bit like come on
            dynamicAddress = (staticAddress - staticBase) + dynamicBase; // Main Conversion
            std::cout << "DEBUG: " << dynamicAddress << std::endl;
            std::stringstream ss;
            ss << std::hex << dynamicAddress; // Decimal To hex
            std::cout << "Dynamic Address: " << ss.str() << std::endl;
            std::this_thread::sleep_for(std::chrono::seconds(4));
        }
        else if (sod == "D" || sod == "d") {
            std::string dynamicAddressString = "";
            uintptr_t dynamicAddress = 0x0;
            uintptr_t staticAddress = 0x0;
            std::cout << "Dynamic Address: ";
            std::cin >> dynamicAddressString;
            dynamicAddress = std::stoull(dynamicAddressString, 0, 16);
            staticAddress = (dynamicAddress - dynamicBase) + staticBase;
            std::cout << "DEBUG: " << staticAddress << std::endl;
            std::stringstream ss;
            ss << std::hex << staticAddress;
            std::cout << "Static Address: " << ss.str() << std::endl;
            std::this_thread::sleep_for(std::chrono::seconds(4));
        }
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
